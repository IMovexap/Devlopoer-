module.exports.config = {
    event_type: ["group_event"],
    name: "joinNoti",
    version: "1.1.0",
    author: "NLam182 + apdhy edit",
    description: "Chào mừng thành viên mới + ảnh gái"
};

module.exports.run = async function({ api, event }) {
    const { ThreadType, GroupEventType } = require("zca-js");
    const axios = require("axios");
    const fs = require("fs").promises;
    const path = require("path");
    const tempPath = path.join(__dirname, 'temp');

    try { await fs.mkdir(tempPath, { recursive: true }); } catch (e) {}

    if (event.type !== GroupEventType.JOIN) return;

    const { threadId, data } = event;
    if (!data || !data.updateMembers || data.updateMembers.length === 0) return;

    const authorId = data.sourceId;
    const newMembers = data.updateMembers;
    if (newMembers.map(m => m.id).includes(api.getOwnId())) return;

    const tempFilePaths = [];

    try {
        const groupInfo = await api.getGroupInfo(threadId);
        const details = groupInfo.gridInfoMap[threadId];
        const totalMember = details?.totalMember || newMembers.length;

        const authorInfo = await api.getUserInfo(authorId);
        const groupName = details?.name || "nhóm này";
        const authorName = authorInfo.changed_profiles[authorId]?.displayName || "Link mời";

        const avatarUrls = newMembers.map(m => m.avatar).filter(Boolean);

        // ────────────────────────────────────────────────
        // ⚠️ ADD: TẢI ẢNH GÁI RANDOM
        // ────────────────────────────────────────────────
        let girlImgPath = null;
        try {
            const girlURL = "https://img.xiangtuu.com/api/random"; 
            const res = await axios.get(girlURL, { responseType: "arraybuffer" });

            girlImgPath = path.join(tempPath, `girl_${Date.now()}.jpg`);
            await fs.writeFile(girlImgPath, res.data);

            tempFilePaths.push(girlImgPath);
        } catch (_) {
            girlImgPath = null;
        }
        // ────────────────────────────────────────────────

        // Tạo nội dung tin nhắn
        let memberLine;
        if (newMembers.length > 1) {
            const startNum = totalMember - newMembers.length + 1;
            const memberNumbers = Array.from({ length: newMembers.length }, (_, i) => startNum + i);
            memberLine = `✨ Các bạn là thành viên thứ ${memberNumbers.join(', ')} của nhóm (${totalMember} thành viên).`;
        } else {
            memberLine = `✨ Bạn là thành viên thứ ${totalMember} của nhóm (${totalMember} thành viên).`;
        }

        const mentions = [];
        const msgParts = [];
        let currentLength = 0;

        const part1 = "Chào mừng ";
        msgParts.push(part1);
        currentLength += part1.length;

        newMembers.forEach((member, index) => {
            const nameTag = `@${member.dName}`;
            mentions.push({ pos: currentLength, len: nameTag.length, uid: member.id });
            msgParts.push(nameTag);
            currentLength += nameTag.length;
            if (index < newMembers.length - 1) {
                const separator = ", ";
                msgParts.push(separator);
                currentLength += separator.length;
            }
        });

        const part3 = ` đến với ${groupName}!\nChúc bạn một ngày vui vẻ.\n\n${memberLine}\n👤 Thêm bởi: `;
        msgParts.push(part3);
        currentLength += part3.length;

        const authorTag = `@${authorName}`;
        mentions.push({ pos: currentLength, len: authorTag.length, uid: authorId });
        msgParts.push(authorTag);

        const msg = msgParts.join("");

        const messagePayload = { msg, mentions, ttl: 15000 };

        // Tải avatar thành viên
        if (avatarUrls.length > 0) {
            const downloadPromises = avatarUrls.slice(0, 5).map(async (url, index) => {
                const tempFilePath = path.join(tempPath, `avatar_${Date.now()}_${index}.jpg`);
                try {
                    const response = await axios.get(url, { responseType: "arraybuffer" });
                    await fs.writeFile(tempFilePath, response.data);
                    tempFilePaths.push(tempFilePath);
                    return tempFilePath;
                } catch (_) { return null; }
            });

            const resolved = await Promise.all(downloadPromises);
            messagePayload.attachments = resolved.filter(Boolean);

            // ⚠️ ADD ảnh gái
            if (girlImgPath) messagePayload.attachments.push(girlImgPath);
        } else {
            // Không có avatar → chỉ gửi ảnh gái
            if (girlImgPath) messagePayload.attachments = [girlImgPath];
        }

        await api.sendMessage(messagePayload, threadId, ThreadType.Group);

    } catch (error) {
        console.error("Lỗi:", error);
    } finally {
        for (const f of tempFilePaths) {
            try { await fs.unlink(f); } catch (_) {}
        }
    }
};