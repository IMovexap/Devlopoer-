const { convertTimestamp, getMessageCache } = require("../../utils/index");
const fs = require("fs").promises;
const path = require("path");
const axios = require("axios");
const { ThreadType } = require("zca-js");

module.exports.config = {
  name: "anti",
  version: "1.1.7",
  role: 1,
  author: "apdhy",
  description: "Bật/tắt các chế độ Anti của nhóm",
  category: "Nhóm",
  usage: "anti <link|undo|spam>",
  cooldowns: 2
};

const baseUndoMsg = `👤 {name} đã thu hồi tin nhắn sau...\n` +
  `⏰ Thời gian gửi: {time_send}\n` +
  `🔔 Thời gian thu hồi: {time_undo}\n` +
  `📝 Nội Dung: {content}`;

function formatUndoMessage(name, timeSend, timeUndo, content) {
  return baseUndoMsg
    .replace('{name}', name)
    .replace('{time_send}', convertTimestamp(timeSend))
    .replace('{time_undo}', convertTimestamp(timeUndo))
    .replace('{content}', content || "");
}

/**
 * Kiểm tra object/string có chứa link hay không.
 * Hỗ trợ:
 * - string thuần
 * - object có thuộc tính text, title, href, content (đôi khi nested)
 */
function containsLink(content) {
  if (!content) return false;

  const LINK_RE = /https?:\/\/[^\s]+/i;

  if (typeof content === "string") {
    return LINK_RE.test(content);
  }

  // check common string fields
  const fields = ["text", "title", "href", "content", "message"];
  for (const f of fields) {
    const val = content[f];
    if (typeof val === "string" && LINK_RE.test(val)) return true;
  }

  // if nested object, try JSON stringify (safe)
  try {
    const s = JSON.stringify(content);
    return LINK_RE.test(s);
  } catch (err) {
    return false;
  }
}

async function handlePhoto(messageCache, tempPath, name, timeSend, timeUndo, threadId, api, type) {
  // messageCache.content.href expected
  const href = messageCache?.content?.href;
  if (!href) {
    // fallback: just send text undo message
    const msgBody = formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || "");
    await api.sendMessage({ msg: msgBody }, threadId, type);
    return null;
  }

  const tempFileName = `anti_undo_${Date.now()}_${Math.floor(Math.random() * 10000)}.jpg`;
  const tempFilePath = path.join(tempPath, tempFileName);

  await fs.mkdir(tempPath, { recursive: true });

  try {
    const response = await axios.get(href, { responseType: 'arraybuffer' });
    await fs.writeFile(tempFilePath, response.data);

    const message = messageCache.content.title || "";
    const msgBody = formatUndoMessage(name, timeSend, timeUndo, message);

    await api.sendMessage({ msg: msgBody, attachments: [tempFilePath] }, threadId, type);
    return tempFilePath;
  } catch (err) {
    console.error("[handlePhoto] Download/send failed:", err.message || err);
    // fallback to text message
    const msgBody = formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || "");
    await api.sendMessage({ msg: msgBody }, threadId, type);
    return null;
  }
}

async function isAdmin(api, userId, threadId) {
  try {
    const info = await api.getGroupInfo(threadId);
    // Safely obtain group info - APIs differ slightly
    const groupInfo = (info && (info.gridInfoMap?.[threadId] || info.groupInfoMap?.[threadId] || info[threadId])) || null;
    if (!groupInfo) return false;

    const isCreator = groupInfo.creatorId && groupInfo.creatorId === userId;
    const adminIds = Array.isArray(groupInfo.adminIds) ? groupInfo.adminIds : (groupInfo.adminIdList || []);
    const isDeputy = Array.isArray(adminIds) && adminIds.includes(userId);

    return !!(isCreator || isDeputy);
  } catch (err) {
    console.error("[isAdmin] getGroupInfo error:", err && err.message ? err.message : err);
    // In case of error, be conservative: treat as non-admin to allow anti actions
    return false;
  }
}

module.exports.handleEvent = async function ({ event, api, Threads, eventType }) {
  const { threadId, isGroup, data, type } = event;
  const typeUndo = isGroup ? 1 : 0;
  const userId = data.uidFrom;
  const name = data.dName || "Bạn";

  const threadDataRaw = (await Threads.getData(threadId)) || {};
  const threadData = threadDataRaw.data || {};
  const tempPath = path.join(__dirname, "temp");
  const tempFiles = [];

  try {
    // === Anti Link ===
    if (threadData.anti_link) {
      // Detect link in different message types
      const isRecommendedLink = (data.msgType === "chat.recommended" && data.content && data.content.action === "recommened.link");
      const isWebchatLink = (data.msgType === "webchat" && containsLink(data.content));
      const isChatPlainLink = (data.msgType === "chat" && containsLink(data.content));
      const isOtherLink = containsLink(data.content);

      if (isRecommendedLink || isWebchatLink || isChatPlainLink || isOtherLink) {
        if (await isAdmin(api, userId, threadId)) return;
        // delete the offending message
        try {
          await api.deleteMessage({
            threadId,
            type,
            data: {
              cliMsgId: data.cliMsgId,
              msgId: data.msgId,
              uidFrom: userId
            }
          }, false);
        } catch (err) {
          console.error("[AntiLink] deleteMessage failed:", err && err.message ? err.message : err);
        }

        const msg = `🚫 @${name}, không được gửi link trong nhóm này!`;
        return api.sendMessage({
          msg,
          mentions: [{ pos: 3, uid: userId, len: name.length + 1 }],
          ttl: 15000
        }, threadId, type);
      }
    }

    // === Anti Spam ===
    const SPAM_LIMIT = 5;
    const SPAM_TIME = 5000; // ms
    const now = Date.now();

    global.spamCache = global.spamCache || {};
    const spamCache = global.spamCache;

    if (threadData.anti_spam) {
  if (!spamCache[threadId]) spamCache[threadId] = {};
  if (!spamCache[threadId][userId]) spamCache[threadId][userId] = [];

  // Admin không bao giờ bị chặn
  if (await isAdmin(api, userId, threadId)) return;

  spamCache[threadId][userId].push(now);
  spamCache[threadId][userId] = spamCache[threadId][userId].filter(ts => (now - ts) <= SPAM_TIME);

  if (spamCache[threadId][userId].length > SPAM_LIMIT) {
    spamCache[threadId][userId] = [];

    // Thêm vào ban-list 5 phút
    global.banCache[threadId][userId] = {
      until: Date.now() + BAN_TIME
    };

    try {
      await api.deleteMessage({
        threadId,
        type,
        data: { cliMsgId: data.cliMsgId, msgId: data.msgId, uidFrom: userId }
      }, false);
    } catch (e) {}

    return api.sendMessage(
      `Antispam: 🚫 @${name} đã bị BAN 5 phút do spam quá mức!`,
      threadId,
      type,
      undefined,
      [{ uid: userId, pos: 2, len: name.length + 1 }]
    );
  }
}
    // === Anti Undo ===
    if (threadData.anti_undo && eventType === "undo") {
      const cliId = data?.content?.cliMsgId;
      const messageCache = getMessageCache()[cliId];
      if (!messageCache) return;

      const timeSend = messageCache.timestamp || 0;
      const timeUndo = data.ts || Date.now();

      const sendUndoMessage = async (msg, extra) => {
        try {
          await api.sendMessage({ msg, ...(extra || {}) }, threadId, typeUndo);
        } catch (err) {
          console.error("[AntiUndo] sendUndoMessage failed:", err && err.message ? err.message : err);
        }
      };

      switch (messageCache.msgType) {
        case "chat.photo": {
          try {
            const filePath = await handlePhoto(messageCache, tempPath, name, timeSend, timeUndo, threadId, api, typeUndo);
            if (filePath) tempFiles.push(filePath);
          } catch (err) {
            console.error("[AntiUndo chat.photo]:", err && err.message ? err.message : err);
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || ""));
          }
          break;
        }

        case "chat.video.msg": {
          try {
            const content = messageCache.content || {};
            const videoUrl = content.href || content.url;
            const thumbnailUrl = content.thumb || content.thumbnail;
            let duration = 0, width = 0, height = 0;

            if (content.params) {
              try {
                const params = typeof content.params === "string" ? JSON.parse(content.params) : content.params;
                duration = params.duration || params.time || duration;
                width = params.video_width || params.width || width;
                height = params.video_height || params.height || height;
              } catch (err) {
                // ignore params parse error
              }
            }

            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo));
            if (videoUrl) {
              await api.sendVideo({ videoUrl, thumbnailUrl, duration, height, width }, threadId, typeUndo);
            }
          } catch (err) {
            console.error("[AntiUndo chat.video.msg] error:", err && err.message ? err.message : err);
          }
          break;
        }

        case "chat.sticker": {
          try {
            const content = messageCache.content || {};
            const id = content.id || content.stickerId;
            const catId = content.catId || content.cateId || content.category;
            const stickerType = content.type || content.stickerType;

            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo));
            if (id) {
              await api.sendSticker({ id, cateId: catId, type: stickerType }, threadId, typeUndo);
            }
          } catch (err) {
            console.error("[AntiUndo chat.sticker] error:", err && err.message ? err.message : err);
          }
          break;
        }

        case "chat.voice": {
          try {
            const voiceUrl = messageCache.content?.href || messageCache.content?.url;
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo));
            if (voiceUrl) {
              await api.sendVoice({ voiceUrl }, threadId, typeUndo);
            }
          } catch (err) {
            console.error("[AntiUndo chat.voice] error:", err && err.message ? err.message : err);
          }
          break;
        }

        case "chat.recommended": {
          try {
            const { action, href, title, params } = messageCache.content || {};
            if (action === "recommened.link" && href) {
              const msg = formatUndoMessage(name, timeSend, timeUndo, (title || "").replace(href, ""));
              await api.sendLink({ msg, link: href }, threadId, typeUndo);
            } else if (action === "recommened.user") {
              await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo));
              await api.sendCard({ userId: params }, threadId, typeUndo);
            } else {
              await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, title || ""));
            }
          } catch (err) {
            console.error("[AntiUndo chat.recommended] error:", err && err.message ? err.message : err);
          }
          break;
        }

        case "chat.gif":
        case "share.file": {
          const fileUrl = messageCache.content?.href || messageCache.content?.url;
          if (!fileUrl) {
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || ""));
            break;
          }

          try {
            const response = await axios.get(fileUrl, { responseType: "arraybuffer" });

            let fileName = `anti_undo_${Date.now()}.dat`;
            const disposition = response.headers && response.headers["content-disposition"];
            if (disposition && disposition.includes("filename=")) {
              const match = disposition.match(/filename="?([^"]+)"?/);
              if (match && match[1]) {
                // sanitize filename a little
                const safe = match[1].replace(/[^a-zA-Z0-9.\-_]/g, "_");
                fileName = `${Date.now()}_${safe}`;
              }
            }

            await fs.mkdir(tempPath, { recursive: true });
            const tempFilePath = path.join(tempPath, fileName);
            await fs.writeFile(tempFilePath, response.data);

            const msgBody = formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || "");
            await api.sendMessage({
              msg: msgBody,
              attachments: [tempFilePath]
            }, threadId, typeUndo);

            tempFiles.push(tempFilePath);
          } catch (err) {
            console.error("[share.file] Download failed:", err && err.message ? err.message : err);
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.title || ""));
          }
          break;
        }

        case "webchat": {
          try {
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, typeof messageCache.content === "string" ? messageCache.content : (messageCache.content?.text || JSON.stringify(messageCache.content))));
          } catch (err) {
            console.error("[AntiUndo webchat] error:", err && err.message ? err.message : err);
          }
          break;
        }

        default: {
          // fallback: just resend text info
          try {
            await sendUndoMessage(formatUndoMessage(name, timeSend, timeUndo, messageCache.content?.text || messageCache.content || ""));
          } catch (err) {
            console.error("[AntiUndo default] error:", err && err.message ? err.message : err);
          }
          break;
        }
      }
    }
  } catch (err) {
    console.error("Lỗi khi xử lý anti:", err && err.message ? err.message : err);
  } finally {
    for (const file of tempFiles) {
      if (!file) continue;
      try {
        await fs.unlink(file);
      } catch (err) {
        console.error(`Không thể xóa file tạm ${file}:`, err && err.message ? err.message : err);
      }
    }
  }
};

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadId, type } = event;
  const action = (args[0] || "").toLowerCase();

  if (type !== ThreadType.Group) {
    return api.sendMessage("Lệnh này chỉ có thể được sử dụng trong nhóm chat.", threadId, type);
  }

  const keyMap = {
    link: "anti_link",
    undo: "anti_undo",
    spam: "anti_spam"
  };

  const key = keyMap[action];

  if (!key) {
    return api.sendMessage(
      "🛡️ Quản lý chế độ Anti của nhóm (apdhy_bot) \n\n" +
      "• anti undo - Chống thu hồi tin nhắn\n" +
      "• anti link - Chống gửi link\n" +
      "• anti spam - Chống spam tin nhắn\n",
      threadId,
      type
    );
  }

  const threadData = await Threads.getData(threadId);
  // ensure data object exists
  threadData.data = threadData.data || {};
  const currentValue = threadData.data[key] || false;
  const newValue = !currentValue;

  threadData.data[key] = newValue;
  await Threads.setData(threadId, threadData.data);

  return api.sendMessage(
    `✅ Đã ${newValue ? "bật" : "tắt"} chế độ Anti ${key.replace("anti_", "").toUpperCase()}.`,
    threadId,
    type
  );
};