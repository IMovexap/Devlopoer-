const { updateConfigArray, reloadConfig } = require("../../utils/index");

module.exports.config = {
  name: 'admin',
  version: '1.1.0',
  role: 2,
  author: 'apdhy',
  description: 'Quản lý admin và support của bot bằng ID hoặc tag.',
  category: 'Hệ thống',
  usage: 'admin <add|rm|sp|rmsp|list> [@tag/ID] (có thể tag nhiều người, nhập nhiều uid cách nhau dấu cách hoặc ,)',
  cooldowns: 2
};

module.exports.run = async ({ args, event, api, Threads }) => {
  const action = args[0]?.toLowerCase();
  const { threadId, type, data } = event;

  let targetIds = [];

  // Nếu có tag
  if (data.mentions && Object.keys(data.mentions).length > 0) {
    targetIds = Object.values(data.mentions).map(m => m.uid || m.id).filter(Boolean);
  }

  // Nếu nhập ID bằng text
  if (targetIds.length === 0 && args.length > 1) {
    targetIds = args.slice(1)
      .join(" ")
      .split(/[\s,]+/)
      .filter(n => n && /^[0-9]+$/.test(n));
  }

  // Đảm bảo global.users tồn tại
  if (!global.users) global.users = {};
  if (!global.users.admin) global.users.admin = [];
  if (!global.users.support) global.users.support = [];

  const processAdd = async (listName, label) => {
    if (targetIds.length === 0)
      return api.sendMessage(`Vui lòng nhập ID hoặc tag người dùng cần thêm làm ${label}.`, threadId, type);

    const currentList = global.users[listName] || [];
    const newIds = targetIds.filter(id => !currentList.includes(id));

    if (newIds.length === 0)
      return api.sendMessage("Không có người dùng nào mới cần thêm.", threadId, type);

    await updateConfigArray(`${listName}_bot`, [...currentList, ...newIds]);
    await reloadConfig();

    const infos = await Promise.all(newIds.map(id => api.getUserInfo(id).catch(() => null)));

    const names = infos.map((info, i) => {
      const uid = newIds[i];
      return `${info?.name || info?.firstName || "Không rõ"} - ${uid}`;
    });

    return api.sendMessage(`✅ Đã thêm ${label}:\n` + names.join("\n"), threadId, type);
  };

  const processRemove = async (listName, label) => {
    if (targetIds.length === 0)
      return api.sendMessage(`Vui lòng nhập ID hoặc tag người dùng cần gỡ khỏi ${label}.`, threadId, type);

    const currentList = global.users[listName] || [];
    const existing = targetIds.filter(id => currentList.includes(id));

    if (existing.length === 0)
      return api.sendMessage("Không có người dùng nào trong danh sách hiện tại.", threadId, type);

    await updateConfigArray(`${listName}_bot`, currentList.filter(id => !existing.includes(id)));
    await reloadConfig();

    const infos = await Promise.all(existing.map(id => api.getUserInfo(id).catch(() => null)));

    const names = infos.map((info, i) => {
      const uid = existing[i];
      return `${info?.name || info?.firstName || "Không rõ"} - ${uid}`;
    });

    return api.sendMessage(`✅ Đã gỡ ${label}:\n` + names.join("\n"), threadId, type);
  };

  switch (action) {
    case "add": return processAdd("admin", "admin bot");
    case "rm": return processRemove("admin", "admin bot");
    case "sp": return processAdd("support", "support bot");
    case "rmsp": return processRemove("support", "support bot");

    case "list": {
      const adminList = global.users.admin || [];
      const supportList = global.users.support || [];

      const adminInfos = await Promise.all(adminList.map(id => api.getUserInfo(id).catch(() => null)));
      const supportInfos = await Promise.all(supportList.map(id => api.getUserInfo(id).catch(() => null)));

      let msg = "--- DANH SÁCH QUẢN TRỊ ---\n\n";

      msg += "👑 Admin Bot:\n";
      msg += adminList.length > 0
        ? adminList.map((uid, i) => ` - ${(adminInfos[i]?.name || "Không rõ")} - ${uid}`).join("\n")
        : "Không có admin nào.";

      msg += "\n\n🛠️ Support Bot:\n";
      msg += supportList.length > 0
        ? supportList.map((uid, i) => ` - ${(supportInfos[i]?.name || "Không rõ")} - ${uid}`).join("\n")
        : "Không có support nào.";

      return api.sendMessage(msg, threadId, type);
    }

    // Bật tắt chế độ
    case "adminonly":
    case "supportonly":
    case "boxonly": {
      const keyMap = {
        adminonly: "admin_only",
        supportonly: "support_only",
        boxonly: "box_only"
      };

      const key = keyMap[action];

      const threadData = await Threads.getData(threadId);
      const current = threadData.data[key] || false;

      threadData.data[key] = !current;

      await Threads.setData(threadId, threadData.data);

      return api.sendMessage(
        `✅ Đã ${!current ? "bật" : "tắt"} chế độ ${key.replace("_", " ")}.`,
        threadId, type
      );
    }

    default:
      return api.sendMessage(
        "Quản lý admin bot\n\n" +
        "admin add [@tag/ID...] - Thêm admin\n" +
        "admin rm [@tag/ID...] - Gỡ admin\n" +
        "admin sp [@tag/ID...] - Thêm support\n" +
        "admin rmsp [@tag/ID...] - Gỡ support\n" +
        "admin list - Xem danh sách\n\n" +
        "admin adminonly - Bật/tắt chỉ admin dùng bot\n" +
        "admin supportonly - Bật/tắt chỉ support dùng bot\n" +
        "admin boxonly - Bật/tắt chỉ dùng được trong nhóm",
        threadId, type
      );
  }
};