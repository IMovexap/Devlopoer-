const fs = require("fs");
const path = require("path");

// File lưu danh sách ban
const banFile = path.join(__dirname, "banlist.json");

// Tạo file nếu chưa có
if (!fs.existsSync(banFile)) fs.writeFileSync(banFile, JSON.stringify({}));

function loadBanList() {
    return JSON.parse(fs.readFileSync(banFile));
}

function saveBanList(data) {
    fs.writeFileSync(banFile, JSON.stringify(data, null, 2));
}

module.exports = {
    name: "ban",
    description: "Ban hoặc unban thành viên",
    role: 2,
    usages: "/ban @tag | /ban ID | /ban help",
    cooldown: 3,

    async execute({ api, event, args }) {
        const { threadId, userId, type } = event;

        // 🔥 KIỂM TRA ADMIN BOT
        if (!global.users.admin.includes(userId.toString())) {
            return api.sendMessage("❌ Bạn không có quyền sử dụng lệnh này.", threadId, type);
        }

        const banList = loadBanList();

        // HELP
        if (args[0] === "help") {
            return api.sendMessage(
                "📘 HƯỚNG DẪN LỆNH BAN\n\n" +
                "👉 /ban @tag — Ban người được tag\n" +
                "👉 /ban ID — Ban theo ID\n" +
                "👉 /unban ID — Gỡ ban\n" +
                "👉 /ban list — Xem danh sách ban\n",
                threadId, type
            );
        }

        // LIST
        if (args[0] === "list") {
            let text = "📌 Danh sách người bị ban:\n\n";
            for (let id in banList) text += `• ${id}\n`;
            if (Object.keys(banList).length === 0) text = "✔ Danh sách ban đang trống.";
            return api.sendMessage(text, threadId, type);
        }

        // UNBAN
        if (args[0] === "unban") {
            const target = args[1];
            if (!target) return api.sendMessage("❌ Vui lòng nhập ID để unban.", threadId, type);

            if (banList[target]) {
                delete banList[target];
                saveBanList(banList);
                return api.sendMessage(`✔ Đã gỡ ban người dùng ${target}.`, threadId, type);
            } else {
                return api.sendMessage("❌ ID này không nằm trong danh sách ban.", threadId, type);
            }
        }

        // BAN
        let targetId = null;

        if (event.mentions && Object.keys(event.mentions).length > 0)
            targetId = Object.keys(event.mentions)[0];

        if (!targetId && args[0])
            targetId = args[0];

        if (!targetId)
            return api.sendMessage("❌ Bạn chưa nhập ID hoặc tag ai đó.", threadId, type);

        // Không cho ban admin bot
        if (global.users.admin.includes(targetId.toString())) {
            return api.sendMessage("⚠ Không thể ban ADMIN BOT.", threadId, type);
        }

        // Lưu vào danh sách ban
        banList[targetId] = true;
        saveBanList(banList);

        // Kick khỏi nhóm
        try { await api.removeUserFromGroup(targetId, threadId); } catch {}

        return api.sendMessage(`🚫 Người dùng ${targetId} đã bị BAN khỏi nhóm.`, threadId, type);
    }
};